let valtoztatasTortent = false;
let vanHibaEmail = false

let vanHibamezo1 = false
let vanHibamezo2 = false
let vanHibamezo3 = false
let vanHibamezo4 = false
let vanHibamezo5 = false
let vanHibamezo6 = false


function emailEllenorzes(email) {
    let emailEllenorizendo = email.value;
    let emailGmail = /\S+@gmail\.\S+/ 
    let emailYahoo = /\S+@yahoo\.\S+/
    var error = document.getElementById("errorEMAIL")
    if (emailGmail.test(emailEllenorizendo) || emailYahoo.test(emailEllenorizendo) || emailEllenorizendo == "") {
        error.textContent = ""
        // document.getElementById("form-submit").style.display = 'inline-block';
    }
    else {
        error.textContent = "Helytelen email"
        error.style.color = "red"
        document.getElementById("form-submit").style.display = 'none';
    }
}

function urlEllenorzes(url) {
    let vanhiba = false
    let emailEllenorizendo = url.value
    var error = document.getElementById("errorURL")
    if (emailEllenorizendo != "") {
        if (emailEllenorizendo.match("^[A-Za-z0-9/:._]+$")) {
            error.textContent = ""
            var url1 = emailEllenorizendo.split('//');
            if (url1[0] === "http:" || url1[0] === "https:") {
                var host = url1[1].split('.');

                if (host.length > 3) {
                    error.textContent = ""
                    vanhiba = false;
                }
                else {
                    error.textContent = "Hianyzik a domain vagy a subdomain"
                    error.style.color = "red"
                    vanhiba = true
                }
            }

            else {
                error.textContent = "Helytelen email cim (hianyzik http/https) "
                error.style.color = "red"
                vanhiba = true
            }
        }
        else {
            error.textContent = "Helytelen email cim, csak kisbetuket,nagybetuket,alulvonast es kotojelet tartalmazhat az URL"
            error.style.color = "red"
            vanhiba = true
        }
    }
    else {
        error.textContent = ""
        vanhiba = false
    }

    if (!vanhiba)
    {
        // document.getElementById("form-submit").style.display = 'inline-block';
    }
    else
    {
        document.getElementById("form-submit").style.display = 'none';
    }

}

function jelszoEllenorzes(jelszo) {
    let jelszoEllenorzes = jelszo.value
    var error = document.getElementById("errorPWD")
    const specialisKarakterek1 = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]{1}/;
    const specialisKarakterek2 = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]{2}/;
    const specialisKarakterek3 = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]{3,}/;

    const kisbetu = /[a-z]/;
    const nagybetu = /[A-Z]/;
    const szamjegy = /[0-9]/; 

    var hibaelso = -1;
    var hibamasodik = -1;
    var eddigmegfelelo = 1;
    if (specialisKarakterek3.test(jelszoEllenorzes)) {
        hibaelso = 1;
        // error.textContent = "Maximum 2 specialis karaktert tartalmazhat"
        // error.style.color = "red"  
    }
    else
        if (specialisKarakterek1.test(jelszoEllenorzes) || specialisKarakterek2.test(jelszoEllenorzes)) {
            hibaelso = -1;
        }
        else {
            hibaelso = 2;
            // error.textContent = "Nem tartalmaz egyetlen specialis karaktert"
            // error.style.color = "red"
        }



    if (kisbetu.test(jelszoEllenorzes)) {
        if (nagybetu.test(jelszoEllenorzes)) {
            if (szamjegy.test(jelszoEllenorzes)) {
                error.textContent = ""
            }
            else {
                hibamasodik = 1;
                // error.textContent = "Nem tartalmaz szamjegyet"
                // error.style.color = "red" 
            }
        }
        else {
            hibamasodik = 2;
            // error.textContent = "Nem tartalmaz nagybetut"
            // error.style.color = "red" 
        }
    }
    else {
        hibamasodik = 3;
        // error.textContent = "Nem tartalmaz kisbetut"
        // error.style.color = "red" 
    }

    if (hibamasodik == -1 || hibaelso == -1 || jelszoEllenorzes == "") {
        error.textContent = ""
        eddigmegfelelo = 1;
    }
    else {
        error.textContent = "Nem tartalmaz egy vagy maximum 2 specialis karaktert vagy nem tartalmaz kisbetut, nagybetut es szamjegyet"
        error.style.color = "red"
        eddigmegfelelo = -1;
    }

    if (eddigmegfelelo == 1 && jelszoEllenorzes != "") {
        if (jelszoEllenorzes.length < 5) {
            eddigmegfelelo = -1;
            error.textContent = "A jelszo hossza legalabb 5 karakter kell legyen"
            error.style.color = "red"
        }

        if (jelszoEllenorzes.length > 12) {
            eddigmegfelelo = -1;
            error.textContent = "A jelszo hossza maximum 12 karakter lehet"
            error.style.color = "red"
        }
    }

    if (eddigmegfelelo == -1)
    {
        document.getElementById("form-submit").style.display = 'none';
    }
    else
    {
        // document.getElementById("form-submit").style.display = 'inline-block';
    }
    jelszoAtmasolo();

}

function jelszoAtmasolo() 
{
    document.getElementById('form-jelszoEllenorzo').value = document.getElementById('form-jelszo').value;
}

function aktualizalas()
{
    var x = document.getElementById("form-utolsoModositas");
    if (valtoztatasTortent == True)
        x.innerHTML = "Malac";
    valtoztatasTortent = False;
}

function save() {

    if (document.getElementById('form-csNev').value !== '' && document.getElementById('form-vNev').value !== '' && document.getElementById('form-szulDat').value !== '' && document.getElementById('form-email').value !== '' && document.getElementById('form-webOldal').value !== '') {
        document.getElementById('form-vNev').setValue = "";
        document.getElementById('form-szulDat').setValue = "";
        document.getElementById('form-email').setValue = "";
        document.getElementById('form-webOldal').setValue = "";
    }
    else {
        alert("Mindegyik mezőt szükséges kitölteni!");
    }


}

let form_szovegdoboz;


function animate(element)
{
    let eredetiElement = element;
    let elementWidth = element.offsetWidth;
    let parentWidth = element.parentElement.offsetWidth;
    let flag = 0;

    while (element.offsetWidth < element.parentElement.offsetWidth)
    {
        element.innerText = element.innerText + " " + eredetiElement.innerText
    }
    if (document.getElementById("form-iranyValasztas").value == "bal")
    {
        element.style.marginLeft = -elementWidth
        flag = 1200;
    }
    else
    {
        element.style.marginLeft = parentWidth
        flag = 0;
    }

    

     mozgoSzoveg = setInterval(() => {
        elementWidth = element.offsetWidth;
        if (document.getElementById("form-iranyValasztas").value == "bal") {
            element.style.marginLeft = (flag -= 5) + "px";

            if (elementWidth <= -flag) {
                flag = parentWidth;
            }
        } else {
            element.style.marginLeft = (flag += 5) + "px";

            if (parentWidth <= parseInt(element.style.marginLeft)) {
                flag = -elementWidth;
            }
        }
    }, 50);
}
function VezetekNev(nev)
{
    if (nev.match("/^[A-Z]{1}[a-z]{1,}$/"))
        return true;
    else
        return false;
}

window.onload = () =>
{
    form_szovegdoboz = document.getElementById("form_szovegdoboz");
    document.getElementById("mozogos").innerText = form_szovegdoboz.value;
    animate(document.getElementById("mozogos"));

    let text = document.lastModified;
    document.getElementById("demo").innerHTML = "Utolso modositas datuma: " + text;

    var mezo1 = document.getElementById('form-csNev')
    var mezo2 = document.getElementById('form-vNev')
    var mezo3 = document.getElementById('form-szulDat')
    var mezo4 = document.getElementById('form-email')
    var mezo5 = document.getElementById('form-webOldal')
    var mezo6 = document.getElementById('form-jelszo')

    if (mezo1.value == '' || mezo2.value == '' || mezo3.value == '' || mezo4.value == '' ||mezo5.value == '' || mezo6.value == '')
    {
        document.getElementById("form-submit").style.display = 'none';
    }
    else
    {
        document.getElementById("form-submit").style.display = 'block';
    }

}

window.onchange  = () => {
    
    form_szovegdoboz = document.getElementById("form_szovegdoboz");                 //hogy lehessen valtoztatni a szoveget
    document.getElementById("mozogos").innerText = form_szovegdoboz.value;
    
    clearInterval(mozgoSzoveg);
    animate(document.getElementById("mozogos"));

    var mezo1 = document.getElementById('form-csNev')
    var mezo2 = document.getElementById('form-vNev')
    var mezo3 = document.getElementById('form-szulDat')
    var mezo4 = document.getElementById('form-email')
    var mezo5 = document.getElementById('form-webOldal')
    var mezo6 = document.getElementById('form-jelszo')

    if (mezo1.value == '' || mezo2.value == '' || mezo3.value == '' || mezo4.value == '' || mezo5.value == '' || mezo6.value == '' )
    {
        document.getElementById("form-submit").style.display = 'none';
    }
    
    else
    {
        document.getElementById("form-submit").style.display = 'inline-block';
    }

}

function gombUjrakezdes ()
{
    clearInterval(mozgoSzoveg);
    animate(document.getElementById("mozogos"));
}





